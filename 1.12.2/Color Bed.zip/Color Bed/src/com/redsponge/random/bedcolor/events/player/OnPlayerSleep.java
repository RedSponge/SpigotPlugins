package com.redsponge.random.bedcolor.events.player;

import org.bukkit.DyeColor;
import org.bukkit.World;
import org.bukkit.block.Bed;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerBedEnterEvent;

import com.redsponge.random.bedcolor.BedColor;
import com.redsponge.random.bedcolor.BedColor.ConfigPaths;
import com.redsponge.random.bedcolor.BedColorMethods;

public class OnPlayerSleep implements Listener {

	BedColor plugin;
	FileConfiguration config;
	
	public OnPlayerSleep(BedColor instance) {
		plugin = instance;
		config = plugin.getConfig();
	}
	
	@EventHandler
	public void onPlayerSleep(PlayerBedEnterEvent e) {
		if(!config.getBoolean(ConfigPaths.ONE_PLAYER_SLEEP_ENABLE.getPath())) {
			return;
		}
		
		World w = e.getPlayer().getWorld();
		String message = BedColorMethods.setMessagePrefixes("HOWDY", e.getPlayer(), (Block) e.getBed(), ((Bed)e.getBed().getState()).getColor());
		BedColorMethods.broadcastToWorld(w, message);
		w.setTime(0);
		
	}
	
}
